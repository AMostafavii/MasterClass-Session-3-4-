Titanic: one notebook per Kaggle submission

notebooks/     code, one notebook per submission (same name as its csv)
submissions/   the csv files sent to Kaggle (written by the notebooks)
data/          Titanic.csv (train) and test.csv

Run a notebook from inside notebooks/. It reads ../data and writes ../submissions.

file                   model                                          Kaggle accuracy
submission             random forest, raw features                    0.77033
submission_improved1   gradient boosting, extra features              0.77990
submission_improved2   random forest, extra features                  0.76794
submission_improved3   soft voting (LR + RF + GB)                     0.77990
submission_improved4   gradient boosting, interactions and bands      0.77990
submission_improved5   random forest, interactions and bands          0.77033
submission_improved6   random forest, group survival features         0.77033
submission_improved7   stacking, group survival features              0.77990
submission_improved8   gradient boosting, group survival features     0.76076
submission_improved9   RF + XGBoost average, 5 seeds                  0.78708 (best)
submission_improved10  RF + ExtraTrees average, 7 seeds               0.78229

Every notebook was re-run and its csv matches the submitted file row by row.
